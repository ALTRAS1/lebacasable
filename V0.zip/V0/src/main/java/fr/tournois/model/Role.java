package fr.tournois.model;

/**
 * Rôles possibles pour un utilisateur
 */
public enum Role {
    ADMIN,
    ORGANISATEUR
}
